#!/usr/bin/env python3
"""
build_release_index.py  —  ILLUSTRATIVE REFERENCE IMPLEMENTATION

Writes splits/manifest.sha256: one line per index file,
"<sha256>  <filename>", plus a comment giving each partition's row count.
This is the file a reviewer verifies with:  sha256sum -c manifest.sha256

Usage:
    python build_release_index.py --splits ../splits
"""
import argparse, glob, hashlib, os

def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()

def count_rows(path):
    n = 0
    with open(path) as f:
        for line in f:
            if line.strip() and not line.startswith("#"):
                n += 1
    return n

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--splits", default="../splits")
    a = ap.parse_args()
    idx_files = sorted(glob.glob(os.path.join(a.splits, "*.idx")))
    manifest = os.path.join(a.splits, "manifest.sha256")
    with open(manifest, "w") as m:
        m.write("# partition counts:\n")
        for p in idx_files:
            m.write(f"#   {os.path.basename(p)}: {count_rows(p)} rows\n")
        for p in idx_files:
            digest = sha256_of(p)
            m.write(f"{digest}  {os.path.basename(p)}\n")
            print(f"{digest[:8]}…  {os.path.basename(p)}")
    print("wrote", manifest)
    print("verify with:  cd", a.splits, "&& sha256sum -c manifest.sha256")

if __name__ == "__main__":
    main()
