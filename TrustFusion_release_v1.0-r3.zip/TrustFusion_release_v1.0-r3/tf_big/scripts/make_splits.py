#!/usr/bin/env python3
"""
make_splits.py  —  ILLUSTRATIVE REFERENCE IMPLEMENTATION

Builds the random-stratified (P-R) BODMAS family splits and writes one index
file per partition. Each row is:  sha256,first_seen_utc,label

Run on YOUR data:
    python make_splits.py --meta metadata.csv --config ../config/bodmas.yaml --out ../splits

...where metadata.csv has columns: sha256,first_seen_utc,family,benign_source
(this is the per-sample table you already build when preparing BODMAS).

Run the DEMO (no data needed — produces synthetic example files):
    python make_splits.py --demo --out ../splits
"""
import argparse, csv, os, random, hashlib, datetime, collections

RATIOS = {"train": 0.70, "val": 0.075, "cal": 0.075, "test": 0.15}
MIN_FAMILY = 25
HEADER = ("# {fn}  (columns: sha256,first_seen_utc,label)\n")

def load_meta(path):
    rows = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            rows.append((r["sha256"], r["first_seen_utc"], r["family"]))
    return rows

def apply_family_filter(rows):
    counts = collections.Counter(fam for _, _, fam in rows)
    out = []
    for sha, ts, fam in rows:
        label = fam if counts[fam] >= MIN_FAMILY else "residual"
        out.append((sha, ts, label))
    return out

def stratified_split(rows, seed=0):
    rnd = random.Random(seed)
    by_label = collections.defaultdict(list)
    for row in rows:
        by_label[row[2]].append(row)
    parts = {k: [] for k in RATIOS}
    for label, items in by_label.items():
        rnd.shuffle(items)
        n = len(items)
        n_tr = int(n * RATIOS["train"])
        n_va = int(n * RATIOS["val"])
        n_ca = int(n * RATIOS["cal"])
        parts["train"] += items[:n_tr]
        parts["val"]   += items[n_tr:n_tr + n_va]
        parts["cal"]   += items[n_tr + n_va:n_tr + n_va + n_ca]
        parts["test"]  += items[n_tr + n_va + n_ca:]
    return parts

def write_idx(part, rows, out_dir):
    fn = f"bodmas_family_PR_{part}.idx"
    with open(os.path.join(out_dir, fn), "w") as f:
        f.write(HEADER.format(fn=fn))
        for sha, ts, label in rows:
            f.write(f"{sha},{ts},{label}\n")
    return fn, len(rows)

def make_demo_meta(n=240):
    rnd = random.Random(7)
    fams = [f"family_{i:03d}" for i in range(1, 9)]
    start = datetime.datetime(2019, 8, 1); span = (datetime.datetime(2020, 9, 30) - start)
    rows = []
    for i in range(n):
        sha = hashlib.sha256(f"demo{i}".encode()).hexdigest()
        ts = (start + datetime.timedelta(seconds=rnd.randint(0, int(span.total_seconds())))).strftime("%Y-%m-%dT%H:%M:%SZ")
        rows.append((sha, ts, rnd.choice(fams)))
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--meta"); ap.add_argument("--config")
    ap.add_argument("--out", default="../splits"); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--demo", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    rows = make_demo_meta() if a.demo else load_meta(a.meta)
    rows = apply_family_filter(rows)
    parts = stratified_split(rows, seed=a.seed)
    for part in ("train", "val", "cal", "test"):
        fn, n = write_idx(part, parts[part], a.out)
        print(f"wrote {fn}: {n} rows")
    print("Next: python build_release_index.py --splits", a.out)

if __name__ == "__main__":
    main()
