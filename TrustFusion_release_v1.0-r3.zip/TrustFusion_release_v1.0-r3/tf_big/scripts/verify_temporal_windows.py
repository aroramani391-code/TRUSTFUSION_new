#!/usr/bin/env python3
"""
verify_temporal_windows.py  —  ILLUSTRATIVE REFERENCE IMPLEMENTATION

Confirms the temporal (P-T) chronology claimed in the paper:
  * every OPTIMISATION batch (gradient step) falls in Aug-Nov 2019
  * December 2019 appears ONLY as the calibration pool (no gradient step)

Usage:
    python verify_temporal_windows.py --log ../logs/pt_training.log
"""
import argparse, collections, sys

GRAD_MONTHS = {"2019-08", "2019-09", "2019-10", "2019-11"}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", default="../logs/pt_training.log")
    a = ap.parse_args()

    grad_by_month = collections.Counter()
    calib_months = set()
    ok = True

    for line in open(a.log):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "step=" in line:                       # a gradient update
            month = next(t.split("=")[1] for t in line.split() if t.startswith("month="))
            grad_by_month[month] += 1
            if month not in GRAD_MONTHS:
                print(f"  VIOLATION: gradient step in {month}"); ok = False
        elif "CALIBRATION" in line:               # calibration pool, no backprop
            month = next(t.split("=")[1] for t in line.split() if t.startswith("month="))
            calib_months.add(month)

    print("gradient steps by month:", dict(grad_by_month))
    print("calibration-only months:", sorted(calib_months))
    if "2019-12" in grad_by_month:
        print("  VIOLATION: December 2019 supplied a gradient step"); ok = False
    print("RESULT:", "PASS — chronology consistent with the paper" if ok else "FAIL")
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
